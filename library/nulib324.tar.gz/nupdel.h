/*
 * nupdel.h - declarations for NuUpdate and NuDelete
 *
 * NuLib v3.2  March 1992  Freeware (distribute, don't sell)
 * By Andy McFadden (fadden@uts.amdahl.com)
 */


extern void NuDelete(),
	    NuUpdate();

