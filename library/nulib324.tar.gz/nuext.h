/*
 * nuext.h - declarations for nuext.c
 *
 * NuLib v3.2  March 1992  Freeware (distribute, don't sell)
 * By Andy McFadden (fadden@uts.amdahl.com)
 */

#define MAXDEPTH    64	   /* max subdir depth we will unpack */

extern void NuExtract();

