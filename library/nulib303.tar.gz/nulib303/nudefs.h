/*
 * nudefs.h - system-dependent typdefs and #defines for all NuLib files,
 *            plus extern declarations for global variables (allocated in
 *	      numain.c).
 *
 * IMPORTANT: This file must be first on the list of #includes, since some
 *	      include files will be processed based on these #defines
 *
 * NuLib v3.0  February 1991  Freeware (distribute, don't sell)
 * By Andy McFadden (fadden@cory.berkeley.edu)
 */


/* SYSTEM DEPENDENCIES */
typedef unsigned char onebyt;
typedef unsigned short twobyt;
typedef unsigned long fourbyt;

/* byte ordering; TRUE if high byte is first (68xxx), else FALSE (65xxx) */
extern int HiLo;  /* actually part of numain.c */

/* Setup for Apple //gs APW */
/* [ "APW" is automatically defined by the compiler ] */

/* Setup for MS-DOS machines (80xxx based: IBM PC) */
/* [ "MSDOS" is defined by the compiler [MS C5.1 anyway] ] */

/* Setup for other microcomputers (Macintosh, Amiga) */
/* ??? */

/* Setup for AIX */
/* #define SYSV */
/* #define BSD_INCLUDES */

/* Setup for BSD UNIX systems */
/*#define UNIX*/
/*#define BSD43*/
/* #define VAX */

/* Setup for XENIX/386 */
/* NOTE: if you get error messages about readdir() and opendir() during */
/*	 linking, remove the leading '#' from the line "#CLIBS= -lx" in */
/*	 "Makefile"							*/
/* #define XENIX386 */
/* #define UNIX */
/* #define SYSV */
/* #define NO_RENAME */		/* no rename() call in C library */

/* Setup for AOS/VS @ DG */
/* #define UNIX */
/* #define DATAGENERAL */
/* #define AOSVS */

/* Setup for UTS ("UTS" already defined) */
/*#define UNIX
#define SYSV
#define NO_RENAME*/

/* Setup for other UNIX systems */
/* #define UNIX */
/* #define SYSV (or whatever) */

/* use table lookups to get CRCs */
#define CRC_TAB

/*
 * Some global defs
 */

/* errno wasn't defined in <errno.h> on some systems... */
#ifndef MSDOS
extern int errno;
#endif

/* Maximum file name length that we intend to handle (watch stack size!) */
#define MAXFILENAME	   1024

/* file operations */
#define S_ABS	0  /* seek absolute */
#define S_REL	1  /* seek relative */
#define S_END	2  /* seek from end */

#ifdef UNIX	      /* stuff for open() */
# define WPERMS 0644	/* read/write for owner, read only for others */
# define FREAD_STR	"r"
# define FWRITE_STR	"w"
# define O_BINARY 0    /* for non-UNIX open(); easier than #ifdefs */
#else
# ifdef APW
#  define WPERMS 0666	 /* read/write for all; this may not work for some */
#  define FREAD_STR	"rb"
#  define FWRITE_STR	"wb"
# endif
# ifdef MSDOS
#  define S_IREAD     0000400         /* read permission, owner */
#  define S_IWRITE    0000200         /* write permission, owner */
#  define WPERMS S_IREAD | S_IWRITE
#  define FREAD_STR	"rb"
#  define FWRITE_STR	"wb"
# endif
# ifndef WPERMS /* other system */
#  define WPERMS 0666  /* +PORT+ */
#  define FREAD_STR	"rb"
#  define FWRITE_STR	"wb"
# endif
#endif /*UNIX*/

/* Time structure; same as TimeRec from misctool.h */
/* one-byte entries should not have alignment problems... */
typedef struct {
    onebyt second;
    onebyt minute;
    onebyt hour;
    onebyt year;
    onebyt day;
    onebyt month;
    onebyt extra;
    onebyt weekDay;
} Time;


/*
 * global to entire program
 */
extern int HiLo;	/* byte ordering; FALSE on low-first (65816) */
extern int verbose;	/* BOOLEAN: print verbose? */
extern int interact;	/* BOOLEAN: interactive when overwriting? */
extern int dopack;	/* BOOLEAN: do we want to pack/unpack? */
extern int doSubdir;	/* BOOLEAN: expand subdirectories? */
extern int doExpand;	/* BOOLEAN: expand archived filenames? */
extern int doMessages;	/* BOOLEAN: do comments instead of data? */
extern int transfrom;	/* how to do CR<->LF translation?  (-1 = none) */
extern int transto;
extern int packMethod;	/* how to pack a file (thread_format) */
extern fourbyt defFileType;	/* default file type */
extern fourbyt defAuxType;	/* default aux type */
extern onebyt *pakbuf;	/* used by compression routines; created once to */
              /* eliminate overhead involved in malloc()ing a 64K buffer */
extern char *prgName;	/* for errors; don't like argv[0] */

