/*
 * nuext.h - declarations for nuext.c
 *
 * NuLib v3.0  February 1991  Freeware (distribute, don't sell)
 * By Andy McFadden (fadden@cory.berkeley.edu)
 */

#define MAXDEPTH    64	   /* max subdir depth we will unpack */

extern void NuExtract();

