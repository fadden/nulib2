/*
 * nublu.h - declarations for nublu.c
 *
 * NuLib v3.0  February 1991  Freeware (distribute, don't sell)
 * By Andy McFadden (fadden@cory.berkeley.edu)
 */

extern void NuBNY();

