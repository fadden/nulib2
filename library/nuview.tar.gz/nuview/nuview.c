/*
 * nuview.c - prints the contents of a NuFX archive
 *
 * Public domain - fadden@cory.berkeley.edu (Andy McFadden)
 * version 1.1  May 1989
 */

#include <stdio.h>
#include <strings.h>
#include "nuview.h"
#include "nuread.h"
#include "nustr.h"

typedef int BOOLEAN;
#define TRUE	1
#define FALSE	0


/*
 * Usage:  nuview -v			print version number
 *	   nuview archive-name		print archive like ShrinkIt would
 *	   nuview -l archive-name	print full archive info
 */
void Usage(argv0)
char *argv0;
{
    printf("Usage: %s [-v | -l] archive-name\n", argv0);
}


/* print date from Time structure */
char *PrintDate(tptr, brief)
Time *tptr;
BOOLEAN brief;
{
    static char buf[64], buf2[64];

    /* check for validity */
    if ( (tptr->day > 31) || (tptr->month > 11) || (tptr->hour > 24) ||
	(tptr->minute > 59) ) {
	strcpy(buf, "   <invalid>   ");
	return (buf);
    }

    /* only print weekDay if one was stored and if we're in longout mode */
    if (!brief && tptr->weekDay) {
	(void) sprintf(buf, "%s, ", WD[tptr->weekDay]);
    } else {
	buf[0] = '\0';
    }
    (void) sprintf(buf2, "%.2d-%s-%.2d %.2d:%.2d",
	tptr->day, MO[tptr->month], tptr->year,
	tptr->hour, tptr->minute);
    (void) strcat(buf, buf2);
    if (!brief) {  /* add seconds to long output */
	(void) sprintf(buf2, ":%.2d", tptr->second);
	(void) strcat(buf, buf2);
    }
    return (buf);
}


/* Dump contents of the threads */
DumpThreads(RNodePtr)
RNode *RNodePtr;
{
    int i;
    int count = RNodePtr->RHptr->total_threads;
    static char ind[4] = "   ";  /* indentation */
    THblock *THptr;
    TNode *TNodePtr;

    /* go through all threads, printing as we go */
    TNodePtr = RNodePtr->TNodePtr;
    for (i = 0; i < count; i++) {
	if (TNodePtr == (TNode *) NULL) {
	    fprintf(stderr, "WARNING: fewer threads than expected\n");
	    return;
	}
	THptr = TNodePtr->THptr;

	printf("%s --> Information for thread %d\n", ind, i);
	printf("%s thread_class: %s\n", ind, THptr->thread_class < TCn ?
		TC[THptr->thread_class] : UNKNOWNSTR);
	printf("%s thread_format: %s\n", ind, THptr->thread_format < TFn ?
		TF[THptr->thread_format] : UNKNOWNSTR);
	printf("%s thread_kind: %s ($%.2X)\n", ind,
		(THptr->thread_kind < TKn && THptr->thread_class < TCn) ?
		TK[THptr->thread_class][THptr->thread_kind] : UNKNOWNSTR,
		THptr->thread_kind);
	printf("%s thread_eof: %u   ", ind, THptr->thread_eof);
	printf("comp_thread_eof: %u\n", THptr->comp_thread_eof);
	printf("%s * position within file: %ld\n", ind, TNodePtr->fileposn);

	TNodePtr = TNodePtr->TNext;
    }
    /* after all info printed, show sum total of thread lengths */
    printf("%s * total thread_eof: %u   ", ind, RNodePtr->unc_len);
    printf("total comp_thread_eof: %u\n", RNodePtr->comp_len);
}


/* Scan contents of the threads for certain things (for ShrinkIt) */
/* returns 65535 as error code (-1 in an unsigned short) */
twobyt ScanThreads(RNodePtr, format)
RNode *RNodePtr;
twobyt *format;
{
    int i;
    int count = RNodePtr->RHptr->total_threads;
    THblock *THptr;
    TNode *TNodePtr;

    *format = 65535;  /* default = error */
    TNodePtr = RNodePtr->TNodePtr;
    for (i = 0; i < count; i++) {
	if (TNodePtr == (TNode *) NULL) {
	    fprintf(stderr, "WARNING: fewer threads than expected\n");
	    return (65535);
	}
	THptr = TNodePtr->THptr;

	if (THptr->thread_class == 2) {  /* data thread? */
	    *format = THptr->thread_format;
	    return (THptr->thread_kind);
	}
    }
    return (65535);  /* no data thread found */
}


/*
 * View archive contents
 *
 * When "longout" is false, the output resembles a ShrinkIt archive listing
 */

void NuView(archive, filename, longout)
ListHdr *archive;
char *filename;
BOOLEAN longout;
{
    MHblock *MHptr = archive->MHptr;
    RHblock *RHptr;
    RNode *RNodePtr;
    static char tmpbuf[64];
    twobyt format, datakind;
    int percent, i;

    if (!longout) {
	(void) sprintf(tmpbuf, "%.15s", filename);
	printf("%-16s ", tmpbuf);
	printf("Created:%s   ", PrintDate(&MHptr->arc_create_when, TRUE));
	printf("Mod:%s     ", PrintDate(&MHptr->arc_mod_when, TRUE));
	printf("Recs:%5u\n\n", MHptr->total_records);
	printf(" Name                  Kind  Typ  Auxtyp Archived");
	printf("        Fmat Size  Un-Length\n");
	printf("-------------------------------------------------");
	printf("----------------------------\n");
    } else {
	printf("Now processing archive '%s'\n", filename);
	printf("---> Master header information:\n");
	printf("master ID: '%.6s'     ", MHptr->ID);
	printf("master_crc: $%.4X\n", MHptr->master_crc);
	printf("total_records: %u\n", MHptr->total_records);
	printf("created: %s   ", PrintDate(&MHptr->arc_create_when, FALSE));
	printf("mod: %s\n", PrintDate(&MHptr->arc_mod_when, FALSE));
    }

    RNodePtr = archive->RNodePtr;
    for (i = 0; i < MHptr->total_records; i++) {
	if (RNodePtr == (RNode *) NULL) {
	    fprintf(stderr, "WARNING: fewer records than expected\n");
	    return;
	}
	RHptr = RNodePtr->RHptr;
	if (!longout) {
	    printf("%c", (RHptr->access == 0xE3 || RHptr->access == 0xC3) ?
		' ' : '+');
	    (void) sprintf(tmpbuf, "%.21s", RNodePtr->filename);
	    printf("%-21s ", tmpbuf);
	    datakind = ScanThreads(RNodePtr, &format);  /* data_thread info */
	    if (datakind == 65535) {  /* no data thread... */
		printf("????  ");
	        printf("%s  ", RHptr->file_type < 256 ? FT[RHptr->file_type] :
			"???");
	        printf("$%.4X  ", RHptr->extra_type);
	    } else if (datakind == 1) {  /* disk */
		printf("Disk  ");
		printf("---  ");
		(void) sprintf(tmpbuf, "%dk", RHptr->extra_type / 2);
		printf("%-5s  ", tmpbuf);
	    } else {  /* must be a file */
		printf("File  ");
	        printf("%s  ", RHptr->file_type < 256 ? FT[RHptr->file_type] :
			"???");
	        printf("$%.4X  ", RHptr->extra_type);
	    }
	    printf("%s  ", PrintDate(&RHptr->archive_when, TRUE));
	    printf("%s  ", format < QTFn ? QTF[format] : "???");
	    /* figure out the percent size, and format it appropriately */
	    if (!RNodePtr->unc_len && !RNodePtr->comp_len) {
		printf("100%%  ");  /* file is 0 bytes long */
	    } else if ((!RNodePtr->unc_len && RNodePtr->comp_len) ||
			(RNodePtr->unc_len && !RNodePtr->comp_len)) {
		printf("????  ");  /* something weird happened */
	    } else if (RNodePtr->unc_len < RNodePtr->comp_len) {
		printf(">100%% ");  /* compression failed?!? */
	    } else {  /* compute from sum of thread lengths (use only data?) */
	        percent = (((float) RNodePtr->comp_len /
			(float) RNodePtr->unc_len) * 100.0) + 0.5;
		(void) sprintf(tmpbuf, "%.2d%%", percent);
		printf("%-4s  ", tmpbuf);
	        /*printf("%.3d%%  ", percent);*/
	    }
	    printf("%8d\n", RNodePtr->unc_len);
	} else {
	    printf("\n---> Information for record %d:\n", i);
	    printf("Filename: %s\n", RNodePtr->filename);
	    printf("header ID: '%.4s'   ", RHptr->ID);
	    printf("header_crc: $%.4X\n", RHptr->header_crc);
	    printf("attrib_count: %u   ", RHptr->attrib_count);
	    printf("version_number: %u   ", RHptr->version_number);
	    printf("total_threads: %u\n", RHptr->total_threads);
	    printf("file_sys_id: %s   ", RHptr->file_sys_id < FIDn ?
		FID[RHptr->file_sys_id] : UNKNOWNSTR);
	    printf("sep: '%c'\n", (onebyt) RHptr->file_sys_info);
	    printf("sparse: %s (%u)   ", (onebyt) RHptr->file_sys_info >> 8 ?
		"Yes" : "No", (onebyt) RHptr->file_sys_info >> 8);
	    printf("access: %s ($%.8X)\n", (RHptr->access == 0xE3 ||
		RHptr->access == 0xC3) ? "Unlocked" : "Locked", RHptr->access);
	    printf("file_type: %s ($%.8X)   ", RHptr->file_type < 256 ?
	   	 FT[RHptr->file_type] : "???", RHptr->file_type);
	    printf("extra_type: $%.8X\n", RHptr->extra_type);
	    printf("storage_type: %s\n", RHptr->storage_type < STn ?
		ST[RHptr->storage_type] : UNKNOWNSTR);
	    printf("created: %s   ", PrintDate(&RHptr->create_when, FALSE));
	    printf("mod: %s\n", PrintDate(&RHptr->mod_when, FALSE));
	    printf("archived: %s\n", PrintDate(&RHptr->archive_when,
	    	FALSE));
	    /* future expansion... */
	}

	if (longout) DumpThreads(RNodePtr);
	RNodePtr = RNodePtr->RNext;
    }
}


/*
 * Parse args, call functions.  Not idiot-proof by any stretch.
 * In a more complete system, this would be in a different file...
 */

main(argc, argv)
int argc;
char **argv;
{
    ListHdr *archive;
    BOOLEAN longout = FALSE;

    if (argc < 2) {
	Usage(argv[0]);
	exit (0);
    }
    if (!strcmp(argv[1], "-v")) {
	printf("Version 1.1  20-May-89  Public Domain  by Andy McFadden\n");
	exit (0);
    }
    if (!strcmp(argv[1], "-l")) {
	longout = TRUE;
	argv++;
    }

    archive = NuRead(argv[1]);
    NuView(archive, argv[1], longout);
}

