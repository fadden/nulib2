/*
 * nustr.h - string definitions for the various structure entries
 *
 * Public Domain - fadden@cory.berkeley.edu (Andy McFadden)
 * version 1.1  May 1989
 */

#define UNKNOWNSTR	"[ unknown ]"

/* weekDay values */
static char *WD[8] = { "[ null ]", "Sunday", "Monday", "Tuesday", "Wednesday",
		"Thursday", "Friday", "Saturday" };

/* month values */
static char *MO[13] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
		"Aug", "Sep", "Oct", "Nov", "Dec" };

/* thread_class */
#define TCn 4
static char *TC[TCn] = { "Message_thread", "Control_thread", "Data_thread",
		"Sparse_thread" };

#define TKn 3  /* max #of thread_kinds in a thread_class */
static char *TK[TCn][TKn] = {
		{ "ASCII text", "<undef>", "<undef>" },
		{ "Create directory", "<undef>", "<undef>" },
		{ "File data_fork", "Disk image", "File resource_fork" },
		{ "<undef>", "<undef>", "<undef>" } };

/* thread_format */
#define TFn 3
static char *TF[TFn] = { "Uncompressed", "SQueezed (SQ/USQ)",
		"Dynamic LZW (ShrinkIt)" };

/* quick thread_format */
#define QTFn 3
static char *QTF[QTFn] = { "unc", "squ", "shk" };

/* file_sys_id */
#define FIDn 12
static char *FID[FIDn] = { "Reserved ($00)", "ProDOS/SOS", "DOS 3.3", "DOS 3.2",
		"Apple II Pascal", "Macintosh (HFS)", "Macintosh (MFS)",
		"LISA file system", "Apple CP/M", "Reserved ($09)", "MS-DOS",
		"High-Sierra/ISO 9660" };

/* storage_type */
#define STn 14
static char *ST[STn] = { "Standard file", "Standard file", "Standard file",
		"Standard file", "-", "Extended file", "-", "-", "-", "-",
		"-", "-", "-", "Subdirectory" };

/* file type names */
static char *FT[256] = {
	"NON", "BAD", "PCD", "PTX", "TXT", "PDA", "BIN", "CHR",
	"PIC", "BA3", "DA3", "WPD", "SOS", "$0D", "$0E", "DIR",
	"RPD", "RPI", "$12", "OUT", "$14", "RPT", "$16", "$17",
	"$18", "ADB", "AWP", "ASP", "$1C", "$1D", "$1E", "$1F",
	"$20", "$21", "$22", "$23", "$24", "$25", "$26", "$27",
	"$28", "$29", "$2A", "$2B", "$2C", "$2D", "$2E", "$2F",
	"$30", "$31", "$32", "$33", "$34", "$35", "$36", "$37",
	"$38", "$39", "$3A", "$3B", "$3C", "$3D", "$3E", "$3F",
	"$40", "$41", "$42", "$43", "$44", "$45", "$46", "$47",
	"$48", "$49", "$4A", "$4B", "$4C", "$4D", "$4E", "$4F",
	"$50", "$51", "$52", "$53", "$54", "$55", "$56", "$57",
	"$58", "$59", "$5A", "$5B", "$5C", "$5D", "$5E", "$5F",
	"PRE", "$61", "$62", "$63", "$64", "$65", "$66", "$67",
	"$68", "$69", "$6A", "NIO", "$6C", "DVR", "$6E", "HDV",
	"$70", "$71", "$72", "$73", "$74", "$75", "$76", "$77",
	"$78", "$79", "$7A", "$7B", "$7C", "$7D", "$7E", "$7F",
	"$80", "$81", "$82", "$83", "$84", "$85", "$86", "$87",
	"$88", "$89", "$8A", "$8B", "$8C", "$8D", "$8E", "$8F",
	"$90", "$91", "$92", "$93", "$94", "$95", "$96", "$97",
	"$98", "$99", "$9A", "$9B", "$9C", "$9D", "$9E", "$9F",
	"WPF", "MAC", "HLP", "DAT", "$A4", "LEX", "$A6", "$A7",
	"$A8", "$A9", "$AA", "GSB", "ARC", "$AD", "$AE", "$AF",
	"SRC", "OBJ", "LIB", "S16", "RTL", "EXE", "STR", "TSF",
	"NDA", "CDA", "TOL", "DRV", "$BC", "FST", "$BE", "DOC",
	"PNT", "SCR", "ANI", "$C3", "$C4", "$C5", "$C6", "$C7",
	"FON", "FND", "ICN", "$CB", "$CC", "$CD", "$CE", "$CF",
	"$D0", "$D1", "$D2", "$D3", "$D4", "$D5", "$D6", "$D7",
	"$D8", "$D9", "$DA", "$DB", "$DC", "DDD", "$DE", "$DF",
	"LBR", "$E1", "ATI", "$E3", "$E4", "$E5", "$E6", "$E7",
	"$E8", "$E9", "$EA", "$EB", "$EC", "$ED", "$EE", "PAS",
	"CMD", "$F1", "$F2", "$F3", "$F4", "$F5", "$F6", "$F7",
	"$F8", "IMG", "INT", "IVR", "BAS", "VAR", "REL", "SYS" };

