/*
 * nuread.h - linked list structures used for holding NuFX header data,
 *	and structure definitions for archive innards
 *
 * Public domain - fadden@cory.berkeley.edu (Andy McFadden)
 * version 1.1  May 1989
 */

/* SYSTEM DEPENDENCIES */
typedef unsigned char onebyt;
typedef unsigned short twobyt;
typedef unsigned int fourbyt;
#define HILO	/* defined for 68xxx machines, undefined for VAXen */
/*#define LAME*/

/* Maximum file length that we intend to handle */
#define MAXFILENAME	1024

/* "NuFile" in alternating ASCII */
static onebyt MasterID[7] = { 0x4e, 0xf5, 0x46, 0xe9, 0x6c, 0xe5, 0x0 };


/*
 * Structure definitions for NuFX innards
 */

/* Time structure */
typedef struct {
    onebyt second;
    onebyt minute;
    onebyt hour;
    onebyt year;
    onebyt day;
    onebyt month;
    onebyt filler;
    onebyt weekDay;
} Time;

/* master header block */
typedef struct {
    onebyt ID[6];
    twobyt master_crc;
    fourbyt total_records;
    Time arc_create_when;
    Time arc_mod_when;
    onebyt reserved[20];
} MHblock;
#define MHsize 48  /* this should not change */

/* record header block */
typedef struct {
    onebyt ID[4];
    twobyt header_crc;
    twobyt attrib_count;
    twobyt version_number;
    fourbyt total_threads;
    twobyt file_sys_id;
    twobyt file_sys_info;
    fourbyt access;
    fourbyt file_type;
    fourbyt extra_type;
    twobyt storage_type;
    Time create_when;
    Time mod_when;
    Time archive_when;
    /* future expansion here... */
} RHblock;
#define RHsize 56  /* sizeof(RHblock) on a decent compiler */

/* thread record */
typedef struct {
    twobyt thread_class;
    twobyt thread_format;
    twobyt thread_kind;
    twobyt reserved;
    fourbyt thread_eof;
    fourbyt comp_thread_eof;
} THblock;
#define THsize 16  /* this should not change */


/*
 * Definitions for the linked lists
 * A linked list of Record headers, with linked lists of Threads attached
 */

/* thread nodes */
typedef struct TNode_s {
    THblock *THptr;  /* points to thread info */
    long fileposn;  /* absolute position of this thread in the file */
    struct TNode_s *TNext;  /* points to next thread node */
} TNode;

/* record nodes */
typedef struct RNode_s {
    RHblock *RHptr;  /* points to the record header block */
    char *filename;
    TNode *TNodePtr;  /* points to first thread node */
    unsigned int unc_len;  /* total uncompressed length of all threads */
    unsigned int comp_len;  /* total compressed length of all threads */
    struct RNode_s *RNext;  /* points to next record node */
} RNode;

/* head of list */
typedef struct {
    MHblock *MHptr;  /* points to master header */
    RNode *RNodePtr;  /* points to first record node */
} ListHdr;


/*
 * function declarations
 */

extern ListHdr *NuRead();
extern void Seek();

