/*
 * nuread.c - read NuFX archives (header info only) into structures
 *
 * Public domain - fadden@cory.berkeley.edu (Andy McFadden)
 * version 1.1  May 1989
 */

#include <stdio.h>
#include "nuview.h"
#include "nuread.h"

#define TRUE 1
#define FALSE 0

typedef int BOOLEAN;


/* swap two bytes */
void Swap(ptr, a, b)
onebyt *ptr;
register onebyt a, b;
{
    register onebyt tmp;

    tmp = ptr[a], ptr[a] = ptr[b], ptr[b] = tmp;
}

/* copy bytes from buffer to buffer, reversing byte order if necessary */
void BCopy(srcptr, destptr, num, order)
onebyt *srcptr, *destptr;
register int num;
BOOLEAN order;  /* true if byte ordering is important */
{
    register int i = num--;

    if (order) {
#ifdef HILO
	while (i--) {  /* copy & reverse */
	    *(destptr+i) = *(srcptr + num - i);  /* dest+3 = src + 3 - 3 .. */
	}
#else
	while (i--) {  /* copy only */
	    *(destptr+i) = *(srcptr + i);
	}
#endif HILO
    } else {
	while (i--) {  /* byte ordering not important; just copy */
	    *(destptr+i) = *(srcptr+i);
	}
    }
}

#ifdef LAMESEEK
/* seek forward in a FILE in a somewhat lame (but portable) manner */
void Seek(fi, dist)
FILE *fi;
long dist;
{
    long i;

    while ((dist-- > 0L) && (getc(fi) >= 0))
        ;
    if (dist == 0L) return;
    perror("Seek");
    exit (-1);
}

#else
/* seek forward quickly */
void Seek(fi, dist)
FILE *fi;
long dist;
{
    if (fseek(fi, dist, 1 /*incr*/) < 0) {
	perror("Seek");
	exit (-1);
    }
}
#endif LAMESEEK


/*
 * Read thread header data, and skip data fields
 */

TNode *ReadThreads(fi, RHptr, tu_ptr, tc_ptr)
FILE *fi;
RHblock *RHptr;
unsigned int *tu_ptr;  /* pointer to int holding len of uncomp. threads */
unsigned int *tc_ptr;  /* same for sum of comp_thread_eof */
{
    int i, size;
    BOOLEAN first;
    TNode *TNodePtr, *THeadPtr = (TNode *) NULL;
    THblock *THptr;
    char filebuf[THsize];

    first = TRUE;
    for (i = 0; i < RHptr->total_threads; i++) {
	if (first) {  /* create first block, or... */
	    TNodePtr = (TNode *) malloc(sizeof(TNode));
	    THeadPtr = TNodePtr;
	    first = FALSE;
	} else {  /* create next block and go on */
	    TNodePtr->TNext = (TNode *) malloc(sizeof(TNode));
	    TNodePtr = TNodePtr->TNext;
	}
	TNodePtr->TNext = (TNode *) NULL;

	/* Create the thread header block, and read it in */
	TNodePtr->THptr = (THblock *) malloc(sizeof(THblock));
	THptr = TNodePtr->THptr;
	size = fread(filebuf, 1, THsize, fi);  /* should be 16 */
	if (size < THsize) {
	    perror("ReadThread (THblock)");
	    exit (-1);
	}

	/* copy all fields... */
	BCopy(filebuf+0, &THptr->thread_class, 2, TRUE);
	BCopy(filebuf+2, &THptr->thread_format, 2, TRUE);
	BCopy(filebuf+4, &THptr->thread_kind, 2, TRUE);
	BCopy(filebuf+6, &THptr->reserved, 2, TRUE);
	BCopy(filebuf+8, &THptr->thread_eof, 4, TRUE);
	BCopy(filebuf+12, &THptr->comp_thread_eof, 4, TRUE);

	/* update pointers and skip the actual data */
	*tu_ptr += THptr->thread_eof;
	*tc_ptr += THptr->comp_thread_eof;
	TNodePtr->fileposn = ftell(fi);
	Seek(fi, (long) THptr->comp_thread_eof);
    }
    return (THeadPtr);
}


/*
 * Read header data from a NuFX archive into memory
 */

ListHdr *NuRead(filename)
char *filename;
{
    FILE *fi;
    char namebuf[MAXFILENAME];
    int size, i;
    BOOLEAN first;
    twobyt namelen;
    ListHdr *ListPtr;  /* List Header struct */
    MHblock *MHptr;  /* Master Header block */
    RNode *RNodePtr;  /* Record Node */
    RHblock *RHptr;  /* Record Header block */
    onebyt filebuf[RHsize+1];  /* RHsize > MHsize */

    ListPtr = (ListHdr *) malloc(sizeof(ListHdr));  /* create head of list */
    ListPtr->MHptr = (MHblock *) malloc(sizeof(MHblock));  /* master block */

    if ((fi = fopen(filename, "r")) == (FILE *) NULL) {
	fprintf(stderr, "Unable to open archive\n");
	perror("NuRead");
	exit (-1);
    }

    /* create and read the master header block */
    MHptr = ListPtr->MHptr;
    size = fread(filebuf, 1, MHsize, fi);
    if (size < MHsize) {
	perror("NuRead (MHblock)");
	exit (-1);
    }

    BCopy(filebuf+0, MHptr->ID, 6, FALSE);
    BCopy(filebuf+6, &MHptr->master_crc, 2, TRUE);
    BCopy(filebuf+8, &MHptr->total_records, 4, TRUE);
    BCopy(filebuf+12, &MHptr->arc_create_when, 8, FALSE);  /* buggy */
    BCopy(filebuf+20, &MHptr->arc_mod_when, 8, FALSE);
    BCopy(filebuf+28, MHptr->reserved, 20, FALSE);

    if (strncmp(MHptr->ID, MasterID, 6)) {
	fprintf(stderr, "File '%s' is not a NuFX archive\n", filename);
	exit (-1);
    }

    /* main record read loop */
    first = TRUE;
    for (i = 0; i < MHptr->total_records; i++) {
	if (first) {  /* allocate first, or... */
	    ListPtr->RNodePtr = (RNode *) malloc(sizeof(RNode));
	    RNodePtr = ListPtr->RNodePtr;
	    first = FALSE;
	} else {  /* allocate next, and go on */
	    RNodePtr->RNext = (RNode *) malloc(sizeof(RNode));  /* next Rnode */
	    RNodePtr = RNodePtr->RNext;  /* move on to next record */
	}
	RNodePtr->RNext = (RNode *) NULL;

	RNodePtr->RHptr = (RHblock *) malloc(sizeof(RHblock)); /* alloc blk */
	RHptr = RNodePtr->RHptr;
	size = fread(filebuf, 1, RHsize, fi);  /* get known stuff */
	if (size < RHsize) {
	    perror("NuRead (RHblock)");
	    exit (-1);
	}
	BCopy(filebuf+0, RHptr->ID, 4, FALSE);
	BCopy(filebuf+4, &RHptr->header_crc, 2, TRUE);
	BCopy(filebuf+6, &RHptr->attrib_count, 2, TRUE);
	BCopy(filebuf+8, &RHptr->version_number, 2, TRUE);
	BCopy(filebuf+10, &RHptr->total_threads, 4, TRUE);
	BCopy(filebuf+14, &RHptr->file_sys_id, 2, TRUE);
	BCopy(filebuf+16, &RHptr->file_sys_info, 2, TRUE);
	BCopy(filebuf+18, &RHptr->access, 4, TRUE);
	BCopy(filebuf+22, &RHptr->file_type, 4, TRUE);
	BCopy(filebuf+26, &RHptr->extra_type, 4, TRUE);
	BCopy(filebuf+30, &RHptr->storage_type, 2, TRUE);
	BCopy(filebuf+32, &RHptr->create_when, 8, FALSE);
	BCopy(filebuf+40, &RHptr->mod_when, 8, FALSE);
	BCopy(filebuf+48, &RHptr->archive_when, 8, FALSE);

	/* seek past remaining (unknown) attributes to filename length field */
	Seek(fi, (long) RHptr->attrib_count - RHsize - 2);


	size = fread(&namelen, 1, 2, fi);  /* read filename len */
	if (size < 2) {
	    perror("NuRead (namelen)");
	    exit (-1);
	}
#ifdef HILO
	Swap(&namelen, 0, 1);
#endif HILO
	/* read filename, and store in struct */
	size = fread(namebuf, 1, namelen, fi);
	if (size < namelen) {
	    perror("NuRead (namebuf)");
	    exit (-1);
	}
	RNodePtr->filename = (char *) malloc(namelen+1);
	BCopy(namebuf, RNodePtr->filename, namelen, FALSE);  /* store fname */
	RNodePtr->filename[namelen] = '\0';

	RNodePtr->TNodePtr = ReadThreads(fi, RHptr, &RNodePtr->unc_len,
		&RNodePtr->comp_len);
    }

    if (fclose(fi) != 0) {
	perror("NuRead (close)");
	exit (-1);
    }
    return (ListPtr);
}

