/*
 * nuview.h - declarations for nuview.c
 *
 * Public domain - fadden@cory.berkeley.edu (Andy McFadden)
 * version 1.1  May 1989
 */

extern void NuView();

