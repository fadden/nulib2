/*
 * nuread.c - read NuFX archives (header info only) into structures
 *
 * By Andy McFadden (fadden@cory.berkeley.edu)
 * NuLib v2.1  November 1989  Freeware (distribute, don't sell)
 */

#include "nudefs.h"
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

#ifdef MSDOS     /* For file IO */
# include <string.h>
# include <io.h>
# include <sys\types.h>
# include <sys\stat.h>
#endif

#ifdef CRC_TAB
# include "crc.h"     /* fast CRC lookup */
#endif
#include "nuread.h"
#include "nupak.h"  /* uses PAKBUFSIZ */
#include "nuetc.h"


/* quick proc to save x00 bytes of static storage */
void OtherArc(str1, str2)
{
    fprintf(stderr, "File may be %s; try \"%s\".\n", str1, str2);
}

/* swap two bytes if HiLo is TRUE */
void HiSwap(ptr, a, b)
onebyt *ptr;
register onebyt a, b;
{
    register onebyt tmp;

    if (HiLo) {
	tmp = ptr[a], ptr[a] = ptr[b], ptr[b] = tmp;
    }
}


/* copy bytes from buffer to buffer, reversing byte order if necessary */
void BCopy(srcptr, destptr, num, order)
onebyt *srcptr, *destptr;
register int num;
BOOLEAN order;	/* true if byte ordering is important */
{
    register int i = num--;

    if (order && HiLo) {
	while (i--) {  /* copy & reverse */
	    *(destptr+i) = *(srcptr + num - i);  /* dest+3 = src + 3 - 3 .. */
	}
    } else if (order) {
	while (i--) {  /* copy only */
	    *(destptr+i) = *(srcptr + i);
	}
    } else {
	while (i--) {  /* byte ordering not important; just copy */
	    *(destptr+i) = *(srcptr+i);
	}
    }
}


/*
 * Calculate CRC on a region
 *
 * A CRC is the result of a mathematical operation based on the
 * coefficients of a polynomial when multiplied by X^16 then divided by
 * the generator polynomial (X^16 + X^12 + X^5 + 1) using modulo two
 * arithmetic.
 *
 * This routine is a slightly modified verison of one found in:
 * _Advanced Programming Techniques for the Apple //gs Toolbox_
 * By Morgan Davis and Dan Gookin (Compute! Publications, Inc.)
 * It can either calculate the CRC bit-by-bit or use a table.
 * [ one of the few //gs books worth the money	+atm ]
 */
twobyt CalcCRC(seed, ptr, count)
twobyt seed;  /* initial value for CRC */
onebyt *ptr;  /* pointer to start of data buffer */
int count;    /* number of bytes to scan through - note 64K max */
{
    register int x;
    register twobyt CRC = seed;

    do {
#ifndef CRC_TAB
	CRC ^= *ptr++ << 8;		  /* XOR hi-byte of CRC w/data	 */
	for (x = 8; x; --x)		  /* Then, for 8 bit shifts...	 */
	    if (CRC & 0x8000)		  /* Test hi order bit of CRC	 */
		CRC = CRC << 1 ^ 0x1021;  /* if set, shift & XOR w/$1021 */
	    else
		CRC <<= 1;		  /* Else, just shift left once. */
#else
	CRC = updcrc(*ptr++, CRC);	  /* look up new value in table  */
#endif
    } while (--count);
    return (CRC);
}


/*
 * Test an archive's integrity.
 *
 * If the verbose setting is used, it prints CRCs for entire records (headers,
 * threads, etc).
 */
void NuTest(filename, options)
char *filename;
char *options;
{
    ListHdr *archive;
    onebyt *copybuf;  /* buffer for reading record */
    int partial;   /* size for partial read */
    unsigned int rec;
    RNode *RNodePtr;
    MHblock *MHptr;
    TNode *TNodePtr;
    long size;
    int srcfd;	/* file descriptor */
    int thread;
    twobyt CRC;
    long CRCsum = 0L;
    static char *procName = "NuTest";


    printf("Testing %s", filename);
    if (verbose) printf("\n");
    else       { printf("...");  fflush(stdout); }

    archive = NuRead(filename);  /* major glitches cause this to fail */

    MHptr = archive->MHptr;
    RNodePtr = archive->RNodePtr;
    copybuf = (onebyt *) Malloc(PAKBUFSIZ);
    if ((srcfd = open(filename, O_RDONLY | O_BINARY)) < 0)
	Fatal("Unable to close archive", procName);
    if (lseek(srcfd, (long) MHsize, S_ABS) < 0)  /* seek past master block */
	Fatal("Bad seek (MH)", procName);

    for (rec = 0; rec < (unsigned int) MHptr->total_records; rec++) {
	if (verbose) printf("Record %d (%s): ", rec, RNodePtr->filename);
	size = (long) RNodePtr->RHptr->attrib_count;
	size += (long) RNodePtr->namelen;
	TNodePtr = RNodePtr->TNodePtr;
	for (thread=0; thread < (int)RNodePtr->RHptr->total_threads; thread++){
	    if (TNodePtr == (TNode *) NULL) {
		fprintf(stderr, "Internal error: Bad thread structure\n");
		Quit(-1);
	    }
	    size += (long) THsize;
	    size += TNodePtr->THptr->comp_thread_eof;
	    TNodePtr = TNodePtr->TNext;
	}
	if (verbose) { printf("record size = %ld, ", size);  fflush(stdout); }

	CRC = 0;
	while (size != 0L) {
	    if (size > (long) PAKBUFSIZ) {
		partial = (unsigned int) PAKBUFSIZ;
		size -= (long) PAKBUFSIZ;
	    } else {
		partial = (unsigned int) size;
		size = 0L;
	    }

	    if (read(srcfd, copybuf, partial) != partial) {
		fprintf(stderr, "Read error!");
		if (verbose) fprintf(stderr, "\n");
		else fprintf(stderr,
			"Record %d (%s)\n",  rec, RNodePtr->filename);
		fprintf(stderr, "Operation aborted.\n");
		Quit(-1);
	    }
	    if (verbose) CRC = CalcCRC(CRC, copybuf, partial);
	    if (verbose) printf("CRC = $%.4x\n", CRC);
	    if (verbose) CRCsum += CRC;
	}

	RNodePtr = RNodePtr->RNext;
    }
    if (close(srcfd) < 0)
	Fatal("Unable to close archive", procName);

    free(copybuf);
    if (verbose) printf("Sum of CRCs = $%.8lx\n", CRCsum);
    printf("done.\n");
}


/*
 * Read thread header data, and skip data fields
 */

static TNode *ReadThreads(fd, RHptr, tu_ptr, tc_ptr, CRC_ptr)
int fd;
RHblock *RHptr;
fourbyt *tu_ptr,  /* pointer to int holding len of uncomp. threads */
	*tc_ptr;  /* same for sum of comp_thread_eof */
twobyt *CRC_ptr;  /* CRC seed; result is returned thru this */
{
    int i;
    unsigned int size;
    BOOLEAN first;
    TNode *TNodePtr, *THeadPtr = (TNode *) NULL;
    THblock *THptr;
    char filebuf[THsize];
    twobyt CRC = *CRC_ptr;
    static char *procName = "ReadThreads";

    *tu_ptr = 0L, *tc_ptr = 0L;
    first = TRUE;
    for (i = 0; i < RHptr->total_threads; i++) {
	if (first) {  /* create first block, or... */
	    TNodePtr = (TNode *) Malloc(sizeof(TNode));
	    THeadPtr = TNodePtr;
	    first = FALSE;
	} else {  /* create next block and go on */
	    TNodePtr->TNext = (TNode *) Malloc(sizeof(TNode));
	    TNodePtr = TNodePtr->TNext;
	}
	TNodePtr->TNext = (TNode *) NULL;

	/* Create the thread header block, and read it in */
	TNodePtr->THptr = (THblock *) Malloc(sizeof(THblock));
	THptr = TNodePtr->THptr;

	if (size = read(fd, filebuf, THsize) < THsize) {  /* should be 16 */
	    printf("read size = %d, THsize = %d\n", size, THsize);
	    perror("ReadThread (THblock)");
	}
	CRC = CalcCRC(CRC, filebuf, 16);  /* rec hdr CRC part(s) 5/5 */

	/* copy all fields... */
	BCopy(filebuf+0, (onebyt *) &THptr->thread_class, 2, TRUE);
	BCopy(filebuf+2, (onebyt *) &THptr->thread_format, 2, TRUE);
	BCopy(filebuf+4, (onebyt *) &THptr->thread_kind, 2, TRUE);
	BCopy(filebuf+6, (onebyt *) &THptr->reserved, 2, TRUE);
	BCopy(filebuf+8, (onebyt *) &THptr->thread_eof, 4, TRUE);
	BCopy(filebuf+12, (onebyt *) &THptr->comp_thread_eof, 4, TRUE);

	/* update pointers and skip the actual data */
	*tu_ptr += THptr->thread_eof;
	*tc_ptr += THptr->comp_thread_eof;
	if ((TNodePtr->fileposn = lseek(fd, 0L, S_REL)) < 0)
	    Fatal("Bad thread posn lseek()", procName);
	if (THptr->comp_thread_eof > 2097152L)	/* SANITY CHECK */
	    fprintf(stderr, "Sanity check: found comp_thread_eof > 2MB\n");
	if (lseek(fd, (long) THptr->comp_thread_eof, S_REL) < 0)
	    Fatal("Bad seek", procName);
    }
    *CRC_ptr = CRC;
    return (THeadPtr);
}


/*
 * Read header data from a NuFX archive into memory
 */
ListHdr *NuRead(filename)
char *filename;
{
    int fd;  /* archive file descriptor */
    char namebuf[MAXFILENAME];
    int rec, num;
    BOOLEAN first;
    twobyt namelen;
    twobyt CRC;
    ListHdr *ListPtr;  /* List Header struct */
    MHblock *MHptr;  /* Master Header block */
    RNode *RNodePtr;  /* Record Node */
    RHblock *RHptr;  /* Record Header block */
    onebyt filebuf[RECBUFSIZ];	/* must be > RH, MH, or atts-RH size */
    static char *procName = "NuRead";

    ListPtr = (ListHdr *) Malloc(sizeof(ListHdr));  /* create head of list */
    ListPtr->arc_name = (char *) Malloc(strlen(filename)+1); /* archive fnam */
    strcpy(ListPtr->arc_name, filename);
    ListPtr->MHptr = (MHblock *) Malloc(sizeof(MHblock));  /* master block */

    if ((fd = open(filename, O_RDONLY | O_BINARY)) < 0) {
	if (errno == ENOENT) {
	    fprintf(stderr, "%s: can't find file '%s'\n", prgName, filename);
	    Quit (-1);
	} else
	    Fatal("Unable to open archive", procName);
    }

    /* create and read the master header block */
    MHptr = ListPtr->MHptr;
    if (read(fd, filebuf, MHsize) < MHsize) {
	fprintf(stderr, "File '%s' may not be a NuFX archive\n", filename);
	Fatal("Unable to read Master Header Block", procName);
    }

    CRC = CalcCRC(0, filebuf+8, MHsize-8);  /* calc master header CRC */

    /* Copy data to structs, correcting byte ordering if necessary */
    BCopy(filebuf+0, (onebyt *) MHptr->ID, 6, FALSE);
    BCopy(filebuf+6, (onebyt *) &MHptr->master_crc, 2, TRUE);
    BCopy(filebuf+8, (onebyt *) &MHptr->total_records, 4, TRUE);
    BCopy(filebuf+12, (onebyt *) &MHptr->arc_create_when, sizeof(Time), FALSE);
    BCopy(filebuf+20, (onebyt *) &MHptr->arc_mod_when, sizeof(Time), FALSE);
    BCopy(filebuf+28, (onebyt *) MHptr->reserved, 20, FALSE);

    if (strncmp(MHptr->ID, MasterID, 6)) {
	fprintf(stderr, "\nFile '%s' is not a NuFX archive\n", filename);
	if ((filebuf[0] == 10) && (filebuf[1] == 71) &&
	    (filebuf[2] == 76) && (filebuf[18] == 2))
#ifdef NO_BLU
	    OtherArc("Binary II", "unblu");
#else
	    fprintf(stderr, "File may be Binary II; try 'B' option\n");
#endif
	if ((filebuf[0] == '\037') && (filebuf[1] == '\036'))
	    OtherArc("packed", "unpack");
	if ((filebuf[0] == (onebyt)'\377') && (filebuf[1] == '\037'))
	    OtherArc("compacted", "uncompact");
	if ((filebuf[0] == '\037') && (filebuf[1] == (onebyt)'\235'))
	    OtherArc("compressed", "uncompress");
	if ((filebuf[0] == 0x76) && (filebuf[1] == 0xff))
	    OtherArc("SQueezed", "usq");
	if ((filebuf[0] == 0x04) && (filebuf[1] == 0x03) &&
	    (filebuf[2] == 0x4b) && (filebuf[3] == 0x50))
	    OtherArc("a ZIP archive", "UnZip");
	if (!strncmp((char *) filebuf, "SIT!", 4))  /* StuffIt */
	    OtherArc("a StuffIt archive", "StuffIt (Macintosh)");
	if (!strncmp((char *) filebuf, "<ar>", 4))  /* system V arch */
	    OtherArc("a library archive (Sys V)", "ar");
	if (!strncmp((char *) filebuf, "!<arch>", 7))
	    OtherArc("a library archive", "ar");
	if (!strncmp((char *) filebuf, "#! /bin/sh", 10) ||
	    !strncmp((char *) filebuf, "#!/bin/sh", 9))
	    OtherArc("a shar archive", "/bin/sh");
	if (!strncmp((char *) filebuf, "GIF87a", 6))
	    OtherArc("a GIF picture", "?!?");
	/* still need ARC and ZOO */

	Quit (-1);
    }

    if (CRC != MHptr->master_crc)
	printf("WARNING: Master Header block may be corrupted (bad CRC)\n");

    /* main record read loop */
    first = TRUE;
    for (rec = 0; rec < (unsigned int) MHptr->total_records; rec++) {
	if (first) {  /* allocate first, or... */
	    ListPtr->RNodePtr = (RNode *) Malloc(sizeof(RNode));
	    RNodePtr = ListPtr->RNodePtr;
	    first = FALSE;
	} else {  /* allocate next, and go on */
	    RNodePtr->RNext = (RNode *) Malloc(sizeof(RNode)); /* next Rnode */
	    RNodePtr = RNodePtr->RNext;  /* move on to next record */
	}
	RNodePtr->RNext = (RNode *) NULL;

	RNodePtr->RHptr = (RHblock *) Malloc(sizeof(RHblock)); /* alloc blk */
	RHptr = RNodePtr->RHptr;
	if (read(fd, filebuf, RHsize) < RHsize) {  /* get known stuff */
	    fprintf(stderr,"%s: error in record %d (at EOF?)\n", prgName, rec);
	    Fatal("Bad RHblock read", procName);
	}

	CRC = CalcCRC(0, filebuf+6, RHsize-6);	/* rec hdr CRC part 1/5 */

	BCopy(filebuf+0, (onebyt *) RHptr->ID, 4, FALSE);
	BCopy(filebuf+4, (onebyt *) &RHptr->header_crc, 2, TRUE);
	BCopy(filebuf+6, (onebyt *) &RHptr->attrib_count, 2, TRUE);
	BCopy(filebuf+8, (onebyt *) &RHptr->version_number, 2, TRUE);
	BCopy(filebuf+10, (onebyt *) &RHptr->total_threads, 4, TRUE);
	BCopy(filebuf+14, (onebyt *) &RHptr->file_sys_id, 2, TRUE);
	BCopy(filebuf+16, (onebyt *) &RHptr->file_sys_info, 2, TRUE);
	BCopy(filebuf+18, (onebyt *) &RHptr->access, 4, TRUE);
	BCopy(filebuf+22, (onebyt *) &RHptr->file_type, 4, TRUE);
	BCopy(filebuf+26, (onebyt *) &RHptr->extra_type, 4, TRUE);
	BCopy(filebuf+30, (onebyt *) &RHptr->storage_type, 2, TRUE);
	BCopy(filebuf+32, (onebyt *) &RHptr->create_when, sizeof(Time), FALSE);
	BCopy(filebuf+40, (onebyt *) &RHptr->mod_when, sizeof(Time), FALSE);
	BCopy(filebuf+48, (onebyt *) &RHptr->archive_when, sizeof(Time), FALSE);

	if (strncmp(RHptr->ID, RecordID, 4)) {
	    fprintf(stderr, "Found bad record ID (#%d)\n", rec);
	    Quit (-1);
	}

	/* read remaining (unknown) attributes into buffer, if any */
	num = RHptr->attrib_count - RHsize - 2;
	if (num > RECBUFSIZ) {
	    fprintf(stderr, "ERROR: attrib_count > RECBUFSIZ\n");
	    Quit (-1);
	}
	if (num > 0) {
	    if (read(fd, filebuf, num) < num)
		Fatal("Bad xtra attr read", procName);
	    CRC = CalcCRC(CRC, filebuf, num);  /* rec hdr CRC part 2/5 */
	}

	if (read(fd, (char *) &namelen, 2) < 2)  /* read filename len */
	    Fatal("Bad namelen read", procName);
	CRC = CalcCRC(CRC, (onebyt *) &namelen, 2);  /* rec hdr CRC part 3/5 */

	HiSwap(&namelen, 0, 1);
	/* read filename, and store in struct */
	if (namelen > MAXFILENAME) {
	    fprintf(stderr, "ERROR: namelen > MAXFILENAME\n");
	    Quit (-1);
	}
	RNodePtr->namelen = namelen;

	if (read(fd, namebuf, namelen) < namelen)
	    Fatal("Bad namebuf read", procName);
	CRC = CalcCRC(CRC, namebuf, namelen);  /* rec hdr CRC part 4/5 */

	RNodePtr->filename = (char *) Malloc(namelen+1);  /* store fname */
	BCopy(namebuf, (onebyt *) RNodePtr->filename, namelen, FALSE);
	RNodePtr->filename[namelen] = '\0';

	RNodePtr->TNodePtr = ReadThreads(fd, RHptr, &RNodePtr->unc_len,
		&RNodePtr->comp_len, &CRC);
	/* rec hdr CRC part 5/5 calculated by ReadThreads */

	if (CRC != RHptr->header_crc) {
	    printf("WARNING: Detected a bad record header CRC\n");
	    printf("         Rec %d in file '%.60s'\n",rec,RNodePtr->filename);
	}
    }

    /* begin adding new files at  this point */
    if ((ListPtr->nextposn = lseek(fd, 0L, S_REL)) < 0)
	Fatal("Bad final lseek()", procName);

    if (close(fd) < 0) {
	Fatal("Bad close", procName);
    }
    return (ListPtr);
}
