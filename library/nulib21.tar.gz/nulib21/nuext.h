/*
 * nuext.h - declarations for nuext.c
 *
 * By Andy McFadden (fadden@cory.berkeley.edu)
 * NuLib v2.1  November 1989  Freeware (distribute, don't sell)
 */

#define MAXDEPTH    64	   /* max subdir depth we will unpack */

extern void NuExtract();

