/*
 * nupdel.h - declarations for NuDelete
 *
 * By Andy McFadden (fadden@cory.berkeley.edu)
 * NuLib v2.1  November 1989  Freeware (distribute, don't sell)
 */


extern void NuDelete(),
	    NuUpdate();

