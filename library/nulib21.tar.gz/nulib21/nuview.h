/*
 * nuview.h - declarations for nuview.c
 *
 * By Andy McFadden (fadden@cory.berkeley.edu)
 * NuLib v2.1  November 1989  Freeware (distribute, don't sell)
 */

typedef enum { NAMEONLY, PROSHK, FULL } outtype;

/* constant string declarations */
extern char *unknownStr;
extern char *WD[];
extern char *MO[];
#define TCn 4
extern char *TC[];
#define TKn 3
extern char *TK[][TKn];
#define TFn 3
extern char *TF[];
#define QTFn 3
extern char *QTF[];
#define FIDn 12
extern char *FID[];
#define STn 14
extern char *ST[];
extern char *FT[];

extern void NuView();
extern char *PrintDate();

