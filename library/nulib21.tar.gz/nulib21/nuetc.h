/*
 * nuetc.h - declarations for nuetc.c
 *
 * (this will be included by almost all source files; it should come last)
 *
 * By Andy McFadden (fadden@cory.berkeley.edu)
 * NuLib v2.1  November 1989  Freeware (distribute, don't sell)
 */

/* define these if they haven't been already */
#ifndef TRUE
  typedef int BOOLEAN;
# define TRUE	 1
# define FALSE	 0
#endif

#ifdef UNIX
# ifdef BSD43
   extern char *index();    /* BSD version */
   extern char *rindex();
#  define INDEX  index
#  define RINDEX rindex
# else
   extern char *strchr();   /* AT&T version */
   extern char *strrchr();
#  define INDEX  strchr
#  define RINDEX strrchr
# endif
#else
  extern char *strchr();    /* APW, MSC */
  extern char *strrchr();
# define INDEX	strchr
# define RINDEX strrchr
#endif

extern char tmpNameBuf[];

/* external function declarations */
extern void Fatal(),
	    Quit();
extern void free();
extern char *Malloc();

#ifdef APW
extern void ToolErrChk(),
	    perror();
#endif

extern int strcasecmp(),
	   strncasecmp();

extern void ArcfiCreate(),
	    Rename();
extern BOOLEAN Exists();
extern char *MakeTemp();

extern void ExpandTime();
extern long ReduceTime();
extern Time *GetTime();

