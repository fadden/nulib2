/*
 * nuetc.h - declarations for nuetc.c
 *
 * (this will be included by almost all source files; it should come last)
 *
 * By Andy McFadden (fadden@cory.berkeley.edu)
 * NuLib v2.2  April 1990  Freeware (distribute, don't sell)
 */

/* define these if they haven't been already */
/* (this is more of a hassle than I expected... may need "boolean.h" :-) ) */
#ifdef AOSVS							/* BAK */
# ifndef BOOLEAN						/* BAK */
   typedef int BOOLEAN;						/* BAK */
# endif								/* BAK */
#endif								/* BAK */

#ifndef TRUE
# ifndef AOSVS							/* BAK */
   typedef int BOOLEAN;						/* BAK */
# endif								/* BAK */
# define TRUE	 1
# define FALSE	 0
#endif

#ifdef UNIX
# ifdef BSD43
   extern char *index();    /* BSD version */
   extern char *rindex();
#  define INDEX(s, c)  index(s, c)
#  define RINDEX(s, c) rindex(s, c)
# else
   extern char *strchr();   /* AT&T version */
   extern char *strrchr();
#  define INDEX(s, c)  strchr(s, c)
#  define RINDEX(s, c) strrchr(s, c)
# endif
#else
  extern char *strchr();    /* APW, MSC */
  extern char *strrchr();
# define INDEX(s, c)  strchr(s, c)
# define RINDEX(s, c) strrchr(s, c)
#endif

extern char tmpNameBuf[];

/* external function declarations */
extern void Fatal(),
	    Quit();
extern void free();
extern char *Malloc();

#ifdef APW
extern void ToolErrChk(),
	    perror();
#endif

extern int strcasecmp(),
	   strncasecmp();

extern void ArcfiCreate(),
	    Rename();
extern BOOLEAN Exists();
extern char *MakeTemp();

extern void ExpandTime();
extern long ReduceTime();
extern Time *GetTime();

