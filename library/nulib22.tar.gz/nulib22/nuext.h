/*
 * nuext.h - declarations for nuext.c
 *
 * By Andy McFadden (fadden@cory.berkeley.edu)
 * NuLib v2.2  April 1990  Freeware (distribute, don't sell)
 */

#define MAXDEPTH    64	   /* max subdir depth we will unpack */

extern void NuExtract();

