/*
 * nupdel.h - declarations for NuDelete
 *
 * By Andy McFadden (fadden@cory.berkeley.edu)
 * NuLib v2.2  April 1990  Freeware (distribute, don't sell)
 */


extern void NuDelete(),
	    NuUpdate();

