/*
 * This is a stub routine that was used to verify that linking was
 * (otherwise) possible.  It needs to be replaced with an addition to
 * ORCALib.
 *
 * $Id: fdopen.c,v 1.1 1996/11/28 06:16:32 gdr Exp $
 */

#ifndef __ORCAC__
%%% This file should not be compiled by this architecture. %%%
#endif

#include <stdio.h>
#include <assert.h>

FILE *
fdopen (int fd, char *openMode) {
	assert(0);
	return NULL;
}
