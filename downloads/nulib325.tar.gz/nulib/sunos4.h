/*
 * This file is provided for compilation under SunOS 4.3, when an ANSI
 * compiler (such as gcc) is used.  The system header files aren't
 * quite sufficient to eliminate hords of warnings.
 *
 * This header file might be useful for other architecture/compiler
 * combinations as well.  If you use it, try not to break compilations
 * for the remaining combinations.
 *
 * $Id: sunos4.h,v 1.1 1996/10/12 19:16:50 gdr Exp $
 */


#ifndef SUNOS4_H
#define SUNOS4_H

#include <stdio.h>

#ifdef __GNUC__
extern int  _flsbuf __P((int, FILE *));
extern int  _filbuf __P((FILE *));
#else
#endif
extern void bcopy __P((char *, char *, int));
extern int  fclose __P((FILE *));
extern int  fflush __P((FILE *));
extern int  fprintf __P((FILE *, const char *, ...));
extern int  fread __P((char *, int, int, FILE *));
extern int  fseek __P((FILE *, long, int));
extern int  fwrite __P((char *, int, int, FILE *));
extern int  perror __P((const char *));
extern int  printf __P((const char *, ...));
extern int  rename __P((const char *, const char *));
extern int  tolower __P((int));
extern int  setvbuf __P((FILE *, char *, int, int));
extern int  sscanf __P((char *, const char *, ...));
extern int  system __P((const char *));

#endif
