/*
 * nuext.h - declarations for nuext.c
 *
 * NuLib v3.2  March 1992  Freeware (distribute, don't sell)
 * By Andy McFadden (fadden@netcom.com)
 *
 * $Id: nuext.h,v 1.3 1996/11/03 23:01:04 gdr Exp $
 */

#define MAXDEPTH    64	   /* max subdir depth we will unpack */

extern int  AskYesNo __P((void));
extern void ConvFileName __P((char *str));
extern void NuExtract __P((char *filename, int namecount, char **names, 
			   char *options));
extern void SetFInfo __P((char *filename, RHblock *RHptr));
extern void CreateSubdir __P((char *pathname));

