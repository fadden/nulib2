/*
 * nublu.h - declarations for nublu.c
 *
 * NuLib v3.2  March 1992  Freeware (distribute, don't sell)
 * By Andy McFadden (fadden@netcom.com)
 *
 * $Id: nublu.h,v 1.3 1996/11/03 23:01:03 gdr Exp $
 */

extern void NuBNY __P((char *filename, int argc, char **argv, char *options));
