/*
 * nupdel.h - declarations for NuUpdate and NuDelete
 *
 * NuLib v3.2  March 1992  Freeware (distribute, don't sell)
 * By Andy McFadden (fadden@netcom.com)
 *
 * $Id: nupdel.h,v 1.3 1996/11/03 23:01:06 gdr Exp $
 */


extern void NuDelete __P((char *filename, int namecount, char **names,
			  char *options));
extern void NuUpdate __P((char *filename, int namecount, char **names,
			  char *options));
