/*
 * nuview.h - declarations for nuview.c
 *
 * NuLib v3.2  March 1992  Freeware (distribute, don't sell)
 * By Andy McFadden (fadden@netcom.com)
 *
 * $Id: nuview.h,v 1.3 1996/11/03 23:01:07 gdr Exp $
 */

typedef enum { NAMEONLY, PROSHK, ARCZOO, FULL } outtype;

/* constant string declarations */
extern char *unknownStr;
extern char *WD[];
extern char *MO[];
#define TCn 4
extern char *TC[];
#define TKn 3
extern char *TK[][TKn];
#define TFn 6
extern char *TF[];
#define BTFn 6
extern char *BTF[];
#define QTFn 6
extern char *QTF[];
#define FIDn 14
extern char *FID[];
#define STn 14
extern char *ST[];
extern char *FT[];

extern void NuView __P((char *, char *));
extern char *PrintDate __P((Time *, int));

