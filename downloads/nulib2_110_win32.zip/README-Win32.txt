This archive contains the NuLib2 exe for Win32, plus the sample
applications from the NufxLib distribution.  These were built with
assertions and extended tests enabled, which adds a little bit to the
file size and reduces the performance somewhat, but it catches errors
earlier and makes the failure messages more useful.

The latest versions will always be available from http://www.nulib.com/.

